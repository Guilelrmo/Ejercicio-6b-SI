
listado=`cat nombres.txt | wc -l`

contador=1;

while [ $contador -le $listado ];do

i=`cat nombres.txt | head -$contador | tail -1`

mkdir $i

contador=$(($contador+1))

done

numero=$(($1+1))
listado=`cat nombres.txt | wc -l`
contador=1;
contador2=1;
while [ $contador -le $listado ];do
contador2=1;
j=`cat nombres.txt | head -$contador | tail -1`

while [ $contador2 -lt $numero ];do
cd $j
mkdir personal$contador2
contador2=$(($contador2+1))
cd ..
done

contador=$(($contador+1)) 
done



