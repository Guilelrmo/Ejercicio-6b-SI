maxlineas=`cat precipitaciones.txt | wc -l`

linea=1

while [ $linea -le $maxlineas ]; do

i=`cat precipitaciones.txt  | head -$linea | tail -1 | awk {'print $1'}`
j=`cat precipitaciones.txt  | head -$linea | tail -1 | awk {'print $2'}`

if [ $i -eq 1 ] && [ $j -gt 0 ] || [ $i -eq 8 ] && [ $j -gt 0 ];then

echo "Lunes a llovido"

elif [ $i -eq 1 ] && [ $j -eq 0 ] || [ $i -eq 8 ] && [ $j -eq 0 ];then

echo "Lunes no a llovido"

elif [ $i -eq 2 ] && [ $j -gt 0 ] ||  [ $i -eq 9 ] && [ $j -gt 0 ];then

echo "Martes a llovido"

elif [ $i -eq 2 ] && [ $j -eq 0 ] ||  [ $i -eq 9 ] && [ $j -eq 0 ];then

echo "Martes no a llovido"

elif [ $i -eq 3 ] && [ $j -gt 0 ] || [ $i -eq 10 ] && [ $j -gt 0 ];then

echo "Miercoles a llovido"

elif [ $i -eq 3 ] && [ $j -eq 0 ] || [ $i -eq 10 ] && [ $j -eq 0 ];then

echo "Miercoles no a llovido"

elif [ $i -eq 4 ] && [ $j -gt 0 ];then

echo "Jueves a llovido"

elif [ $i -eq 4 ] && [ $j -eq 0 ];then

echo "Jueves no a llovido"

elif [ $i -eq 5 ] && [ $j -gt 0 ];then

echo "Viernes a llovido"

elif [ $i -eq 5 ] && [ $j -eq 0 ];then

echo "Viernes no a llovido"

elif [ $i -eq 6 ] && [ $j -gt 0 ];then

echo "Sabado a llovido"

elif [ $i -eq 6 ] && [ $j -eq 0 ];then

echo "Sabado no a llovido"

elif [ $i -eq 7 ] && [ $j -gt 0 ]; then 

echo "Domingo a llovido"

elif [ $i -eq 7 ] && [ $j -eq 0 ]; then 

echo "Domindo no a llovido"

fi

linea=$(($linea+1))

done
