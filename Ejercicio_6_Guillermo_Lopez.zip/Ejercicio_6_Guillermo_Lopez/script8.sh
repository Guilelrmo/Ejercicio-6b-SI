terminacion=0

while [ $terminacion -le 255 ];do

echo `ping -c 1 192.168.0.$terminacion` >> ip.txt

terminacion=$(($terminacion + 1))

busqueda=`awk '{print $19}' ip.txt`


if [ "$busqueda" != 1 ];then

echo `awk '{print $2}' ip.txt` >> IPS.txt

fi

rm ip.txt

done

cat IPS.txt


