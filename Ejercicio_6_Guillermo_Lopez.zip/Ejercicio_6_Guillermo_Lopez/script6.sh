ficheros=`ls $1/*.txt | wc -l`

rm $1/*.txt 

echo "Se han borrado " $ficheros " ficheros"
