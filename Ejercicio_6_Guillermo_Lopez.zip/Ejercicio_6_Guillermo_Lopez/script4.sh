
for i in $(cat numeros.txt);do

resto=`expr $i % 2`

if [ $resto -eq 0 ]; then

echo $i>>NumerosPares.txt;


else 

echo $i>>NumerosImpares.txt;

fi

done
