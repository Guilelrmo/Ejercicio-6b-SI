maxlineas=`cat listado.txt | wc -l`

linea=1

while [ $linea -le $maxlineas ]; do

i=`cat listado.txt  | head -$linea | tail -1 | awk {'print $2'}`
j=`cat listado.txt  | head -$linea | tail -1 | awk {'print $3'}`

if [ $i == "Windows" ];then

contadorW=$(($contadorW+1))
totalW=`expr $totalW + $j`

elif [ $i == "Linux" ];then

contadorL=$(($contadorL+1))
totalL=`expr $totalL + $j`

fi

linea=$(($linea+1))

done


echo "Windows-> " $contadorW $totalW

echo "Linux->" $contadorL $totalL
