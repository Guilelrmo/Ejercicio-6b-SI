ruta2=`pwd`

cd $1

ruta=`pwd`

if [ "$ruta" != "$ruta2" ];then 

ficheros=`ls $1/*.txt | wc -l`

rm $1/*.txt 

echo "Se han borrado " $ficheros " ficheros"


else 

echo "No existe"

fi
