for i in $(awk '{print $2}' precipitaciones.txt);do
 
suma=$(($i + suma))

contador=$((contador + 1))

done


total=`expr $suma / $contador`

echo "La media es " $total


